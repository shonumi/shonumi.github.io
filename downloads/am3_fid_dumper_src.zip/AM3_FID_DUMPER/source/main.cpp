//By D.S. Baxter - 2022
//Too lazy too license, do whatever, I guess. Trust your instincts.

#include <nds.h>
#include <stdio.h>
#include <fat.h>

volatile int frame = 0;

void Vblank() { frame++; }

#define 	GBA_IME 	(*(vu32 *)(0x04000208))

#define 	GBA_DATA_8 	((vu8 *)(0x08000000))
#define 	GBA_DATA_16 	((vu16 *)(0x08000000))
#define 	GBA_DATA_32 	((vu32 *)(0x08000000))

#define 	AM_BLK_SIZE 	(*(vu16*) 0x08010408)
#define 	AM_BLK_ADDR 	(*(vu32*) 0x08010400)
#define 	AM_BLK_STAT 	(*(vu16*) 0x08010420)

#define 	AM_BLK_404 	(*(vu32*) 0x08010404)
#define 	AM_BLK_40A 	(*(vu16*) 0x0801040A)
#define 	AM_BLK_40C 	(*(vu16*) 0x0801040C)
#define 	AM_BLK_40E 	(*(vu16*) 0x0801040E)

#define 	AM_BLK_400 	(*(vu32*) 0x08010400)
#define 	AM_BLK_410 	(*(vu32*) 0x08010410)

#define 	AM_IO 		((vu8 *)(0x08010400))

void wait_4_stat(u16 stat_bits)
{
	u16 stat_response = 0;

	//Write data to AM_BLK_STAT
	AM_BLK_STAT = stat_bits;

	//Wait for response to equal what was written
	while(stat_response != AM_BLK_STAT)
	{
		stat_response = AM_BLK_STAT;
	}

	//Wait for AM_BLK_STAT Bit 0 to read zero
	while(stat_response & 0x1)
	{
		stat_response = AM_BLK_STAT;
	}
}

void write_am_16(u32 address, u16 value)
{
	GBA_IME = 0;

	vu16* io_reg = (vu16*)address;
	u16 stat_response = 0;

	AM_BLK_STAT = 0x0B;

	//Wait for response to equal what was written
	while(stat_response != AM_BLK_STAT)
	{
		stat_response = AM_BLK_STAT;
	}

	while(stat_response != 0)
	{
		stat_response = AM_BLK_STAT;
	}

	//Write u16 data
	*io_reg = value;

	//Wait for AM_BLK_STAT Bit 0 to read zero
	while(stat_response & 0x4001)
	{
		stat_response = AM_BLK_STAT;
	}

	GBA_IME = 1;
}

void write_am_32(u32 address, u32 value)
{
	GBA_IME = 0;

	vu32* io_reg = (vu32*)address;
	u16 stat_response = 0;

	AM_BLK_STAT = 0x0B;

	//Wait for response to equal what was written
	while(stat_response != AM_BLK_STAT)
	{
		stat_response = AM_BLK_STAT;
	}

	while(stat_response != 0)
	{
		stat_response = AM_BLK_STAT;
	}

	//Write u16 data
	*io_reg = value;

	//Wait for AM_BLK_STAT Bit 0 to read zero
	while(stat_response & 0x4001)
	{
		stat_response = AM_BLK_STAT;
	}

	GBA_IME = 1;
}

int main(void)
{
	irqSet(IRQ_VBLANK, Vblank);

	consoleDemoInit();

	iprintf("AM3 Firmware + SMID Dumper V1\n");

	//Init FAT
	fatInitDefault();

	//Create output binaries
	FILE* firmware_file = fopen("AM3_FIRMWARE.BIN", "w+");
	if(firmware_file == NULL) { iprintf("libfat ERROR!\n"); return 0; }

	FILE* smid_file = fopen("SMID.KEY", "w+");
	if(smid_file == NULL) { iprintf("libfat ERROR!\n"); return 0; }

	sysSetCartOwner(true);

	//Set EXMEMCNT
	REG_EXMEMCNT |= 0x60;

	printf("Dumping SMID...\n");

	//Dump SMID
	for(u32 x = 0; x < 16; x++)
	{
		u8 key_byte = AM_IO[0x10 + x];
		fwrite(&key_byte, 1, 1, smid_file);
	}

	fclose(smid_file);

	printf("Dumping AM3 firmware...\n");

	for(u32 x = 0; x < 12; x++)
	{
		for(u32 index = 0; index < 0x100; index++)
		{
			u32 firm_data = GBA_DATA_32[index];
			fwrite(&firm_data, 4, 1, firmware_file);
		}

		wait_4_stat(0x09);
	}

	fclose(firmware_file);

	printf("Done!\n");
	printf("Press Start to shutdown\n");

	while(1) {
	
		swiWaitForVBlank();
		scanKeys();
		int keys = keysDown();
		if (keys & KEY_START) break;	
	}

	return 0;
}
